﻿namespace AppCore.DataAccess.Configs
{
    public static class ConnectionConfig
    {
        public static string ConnectionString { get; set; }
    }
}
