﻿namespace AppCore.Records.Bases
{
    public abstract class RecordBase
    {
        public int Id { get; set; }
        public string Guid { get; set; }
    }
}
