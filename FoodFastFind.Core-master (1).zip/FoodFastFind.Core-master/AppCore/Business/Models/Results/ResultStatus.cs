﻿namespace AppCore.Business.Models.Results
{
    public enum ResultStatus
    {
        Success = 1,
        Error = 0,
        Exception = -1
    }
}
